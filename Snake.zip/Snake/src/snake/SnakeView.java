package snake;

public class SnakeView {

}
