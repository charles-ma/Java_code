This is a version of the class SnakeModel and its tests.

SnakeModel is observable so that is can be oberved by other observer classes.

There is a timer inside this class so that it will update its own status 25 times a second. And each time it will notify the observers.

The observers can get the status of every cell. In fact the observers can get the cell array as a whole using getGrid method. 

You can set the directions, the speed of the snake, the length of the snake and the size of the grid and so on using corresponding methods in this class.

I have ran tests for all the important methods in this class.

There may exit some problems but I hope not.

If you have any quesions, please contact me.

I will go on to improve the code, too.

~Best    
